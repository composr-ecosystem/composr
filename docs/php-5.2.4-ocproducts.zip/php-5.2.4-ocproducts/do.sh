#!/bin/bash

make ; mv libs/libphp5.so /sw/lib/apache2/modules/ ; apachectl restart ; echo Done
